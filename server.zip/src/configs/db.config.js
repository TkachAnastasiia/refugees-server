const uri = "mongodb+srv://root:tkach30@cluster0.qcf8xjk.mongodb.net/?retryWrites=true&w=majority";

module.exports = uri;
